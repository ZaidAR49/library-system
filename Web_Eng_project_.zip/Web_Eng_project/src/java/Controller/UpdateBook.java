package Controller;
import DAO.BookDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class UpdateBook extends HttpServlet {
    private BookDAO bookDAO = new BookDAO();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String oldTitle = request.getParameter("oldTitle");
            String newTitle = request.getParameter("newTitle");
            String newAuthor = request.getParameter("newAuthor");
            String newGenre = request.getParameter("newGenre");

            if (!bookDAO.isTitleExists(oldTitle)) {
                request.setAttribute("messageUB", "The book with the given title does not exist.");
                request.getRequestDispatcher("admin-dashboard.jsp").forward(request, response);
                return;
            }

            boolean isUpdated = bookDAO.updateBook(oldTitle, newTitle, newAuthor, newGenre);
            if (isUpdated) {
                request.setAttribute("messageUB", "The book has been successfully updated.");
            } else {
                request.setAttribute("messageUB", "Failed to update the book.");
            }

            request.getRequestDispatcher("admin-dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("messageUB", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("admin-dashboard.jsp").forward(request, response);
        }
    }
}
    