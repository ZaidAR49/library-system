package Controller;

import DAO.BookDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "DeleteBook", urlPatterns = {"/DeleteBook"})
public class DeleteBook extends HttpServlet {
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String message = "";
        String title = request.getParameter("title");
        try {
            BookDAO bookDAO = new BookDAO();
    
            if (bookDAO.isTitleExists(title)) {
               
                if (bookDAO.deleteBook(title)) {
                    message = "Delet sucss";
                } else {
                    message = "error";
                }
            } else {
                message = "not found";
            }
        } catch (Exception e) {
            message = "error in databess";
            e.printStackTrace(); 
        } 
        request.setAttribute("messageDB", message);
        request.getRequestDispatcher("admin-dashboard.jsp").forward(request, response);
    }
      @Override
    public String getServletInfo() {
        return "Short description";
    }

}
