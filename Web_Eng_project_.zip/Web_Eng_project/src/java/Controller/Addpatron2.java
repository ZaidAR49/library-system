package Controller;
import Classes.User;
import DAO.UserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Addpatron2 extends HttpServlet { 
    @Override
     protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String role = request.getParameter("role");
    if (!isValidPassword(password)) {
            request.setAttribute("messageAU", "Insert a strong password");
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
            return;
        }
        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.checkUserExists(username)) {
                request.setAttribute("messageAU", "Existing username");
                request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
                return;
            }
            User newUser = new User();
            newUser.setUsername(username);
            newUser.setPassword(password);
            newUser.setRole(role);
            userDAO.addUser(newUser);
            request.setAttribute("messageAU", "User added successfully");
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("messageAU", "Error occurred while adding user");
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
        }
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }
private boolean isValidPassword(String password) {
    String passwordRegex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
    return password.matches(passwordRegex);
}
}
