package Controller;

import Classes.Book;
import Classes.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import static jdk.nashorn.internal.objects.NativeRegExp.test;

@WebServlet(name = "Patron_Servlet", urlPatterns = {"/Patron_Servlet"})
public class Patron_Servlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // processRequest(request, response);
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Patron_Servlet(F)</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>F Servlet Patron_Servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //doPost(request,response);
    //  processRequest(request, response);
        response.setContentType("text/html");
        
        PrintWriter out = response.getWriter();
        out.print("DO GET");
 String not_found = "Data not found ):";
 try{
  Class.forName("oracle.jdbc.OracleDriver");
   Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "Abd2002*");
 Statement s = c.createStatement();
   List<Book> books = new ArrayList<>();
                ResultSet rs = s.executeQuery("SELECT * FROM BOOK");
                if (!rs.isBeforeFirst()) {
                    // No rows found then
                    out.print(not_found);
                }
                while (rs.next()) {
                    String bookTitle = rs.getString("TITLE");
                    String bookAuthor = rs.getString("AUTHOR");
                    String genre = rs.getString("GENRE");
                    int yearPublished = rs.getInt("YEAR_PUBLISHED");
                    int id = rs.getInt("ID");
                    String isbn=rs.getString("ISBN");
                    out.print("Title: " + bookTitle + ", Author: " + bookAuthor + "genre: " + genre + ", published in " + yearPublished + " ,ID :" + id + "<br>");
Book book=new Book(id,yearPublished,bookTitle,bookAuthor,genre,isbn);
                    
if(rs.getString("IS_AVAILABLE").equals("Y"))
book.setIsAvailable(true);
else 
book.setIsAvailable(false);
if(rs.getString("IS_RESERVED").equals("Y"))
book.setIsReserved(true);
else 
book.setIsReserved(false);

books.add(book);  
                }
 if(null!=books){ out.print("message to programer: book is null");}
                  request.getSession().setAttribute("books", books);
               
            
       request.getRequestDispatcher("view_books.jsp").forward(request, response);

             

 
 }catch(Exception e){out.print("Somthig went wrong ---> "+e.getMessage());}
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String not_found = "Data not found ):";
if ("Borrow".equals(request.getParameter("Borrow"))) {
    out.print("Borrow");
    response.sendRedirect("librarian-dashboard.jsp");
}

    ///////////////////////////////////////////////////////////////
        if ((request.getParameter("author") == null || request.getParameter("author").isEmpty()) && (request.getParameter("title") == null || request.getParameter("title").isEmpty())) {
            out.print("<h1>Please enter book author or book title</h1> ");
        }
        ///////////////////////////////////////////////////////////////////Title
        else if (request.getParameter("author") == null || request.getParameter("author").isEmpty()) {
            out.print("Search by title<br> ");
             List<Book> books = new ArrayList<>();
            try {
                Class.forName("oracle.jdbc.OracleDriver");
                Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
                String title = request.getParameter("title");
                Statement s = c.createStatement();
                ResultSet rs = s.executeQuery("SELECT * FROM BOOK WHERE TITLE='" + title + "'");
                if (!rs.isBeforeFirst()) {
                    // No rows found then
                    out.print(not_found);
                }
                while (rs.next()) {
                    String bookTitle = rs.getString("TITLE");
                    String bookAuthor = rs.getString("AUTHOR");
                    String genre = rs.getString("GENRE");
                    int yearPublished = rs.getInt("YEAR_PUBLISHED");
                    int id = rs.getInt("ID");
                    String isbn=rs.getString("ISBN");
                    out.print("Title: " + bookTitle + ", Author: " + bookAuthor + "genre: " + genre + ", published in " + yearPublished + " ,ID :" + id + "<br>");
Book book=new Book(id,yearPublished,bookTitle,bookAuthor,genre,isbn);
                    
if(rs.getString("IS_AVAILABLE").equals("Y"))
book.setIsAvailable(true);
else 
book.setIsAvailable(false);
if(rs.getString("IS_RESERVED").equals("Y"))
book.setIsReserved(true);
else 
book.setIsReserved(false);

books.add(book);
//book.setTitle(rs.getString("TITLE")); i can do this insted but this way to test
                }
                if(null==books){ out.print("message to programer: book is null");}
                else{
                  request.getSession().setAttribute("books", books);   
        
                  request.getRequestDispatcher("Search_Book_Result.jsp").forward(request, response);
                }
            } catch (Exception e) {
                out.print("Somthig went wrong ): thats why -->  "+e.getMessage());
            }

        } else if (request.getParameter("title") == null || request.getParameter("title").isEmpty()) {
            out.print("Search by author ");
            
                    List<Book> books = new ArrayList<>();
            try {
                Class.forName("oracle.jdbc.OracleDriver");
                Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
                String author = request.getParameter("author");
                Statement s = c.createStatement();
                ResultSet rs = s.executeQuery("SELECT * FROM BOOK WHERE author='" + author + "'");
                if (!rs.next()) {
                    // No rows found then
                    out.print(not_found);
                }
                while (rs.next()) {
                    String bookTitle = rs.getString("TITLE");
                    String bookAuthor = rs.getString("AUTHOR");
                    String genre = rs.getString("GENRE");
                    int yearPublished = rs.getInt("YEAR_PUBLISHED");
                    int id = rs.getInt("ID");
                    String isbn=rs.getString("ISBN");
                    out.print("Title: " + bookTitle + ", Author: " + bookAuthor + "genre: " + genre + ", published in " + yearPublished + " ,ID :" + id + "<br>");
Book book=new Book(id,yearPublished,bookTitle,bookAuthor,genre,isbn);
                    
if(rs.getString("IS_AVAILABLE").equals("Y"))
book.setIsAvailable(true);
else 
book.setIsAvailable(false);
if(rs.getString("IS_RESERVED").equals("Y"))
book.setIsReserved(true);
else 
book.setIsReserved(false);

books.add(book);
//book.setTitle(rs.getString("TITLE")); i can do this insted but this way to test
                }
                if(null!=books){ out.print("message to programer: book is null");}
                  request.getSession().setAttribute("books", books);
               
        request.getRequestDispatcher("Search_Book_Result.jsp").forward(request, response);
                
            } catch (Exception e) {
                out.print("Somthig went wrong ): thats why -->  "+e.getMessage());
            }

        } else {
            out.print("Servlet will chose");
                   List<Book> books = new ArrayList<>();
            try {
                Class.forName("oracle.jdbc.OracleDriver");
                Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
                String author = request.getParameter("author");
                String title = request.getParameter("title");
                Statement s = c.createStatement();
                ResultSet rs = s.executeQuery("SELECT * FROM BOOK WHERE author='" + author + "'AND title='"+title+"'");
                if (!rs.isBeforeFirst()) {
                    // No rows found then
                    request.getRequestDispatcher("bookNotFound.html").forward(request, response);
                }
                while (rs.next()) {
                    String bookTitle = rs.getString("TITLE");
                    String bookAuthor = rs.getString("AUTHOR");
                    String genre = rs.getString("GENRE");
                    int yearPublished = rs.getInt("YEAR_PUBLISHED");
                    int id = rs.getInt("ID");
                    String isbn=rs.getString("ISBN");
                    out.print("Title: " + bookTitle + ", Author: " + bookAuthor + "genre: " + genre + ", published in " + yearPublished + " ,ID :" + id + "<br>");
Book book=new Book(id,yearPublished,bookTitle,bookAuthor,genre,isbn);
                    
if(rs.getString("IS_AVAILABLE").equals("Y"))
book.setIsAvailable(true);
else 
book.setIsAvailable(false);
if(rs.getString("IS_RESERVED").equals("Y"))
book.setIsReserved(true);
else 
book.setIsReserved(false);

books.add(book);
//book.setTitle(rs.getString("TITLE")); i can do this insted but this way to test
                }
                if(null!=books){ out.print("message to programer: book is null");}
                  request.getSession().setAttribute("books", books);
               
        request.getRequestDispatcher("Search_Book_Result.jsp").forward(request, response);
                
            } catch (Exception e) {
                //out.print("Somthig went wrong ): thats why -->  "+e.getMessage());
                response.sendRedirect("Error.html");
        }
        }
    }
}

/**
 * Returns a short description of the servlet.
 *
 * @return a String containing servlet description
 */
//    @Override
//    public String getServletInfo() {
//        return "Short description";
//    }// </editor-fold>
//
//}
//
