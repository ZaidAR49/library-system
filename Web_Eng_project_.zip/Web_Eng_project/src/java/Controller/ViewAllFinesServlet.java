package Controller;

import DAO.FineDAO;
import Classes.Fine;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ViewAllFinesServlet", urlPatterns = {"/ViewAllFinesServlet"})
public class ViewAllFinesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        FineDAO fineDAO = new FineDAO();

        try {
            // استرجاع جميع الغرامات من قاعدة البيانات
            List<Fine> fines = fineDAO.getAllFines();
            double totalFines = fineDAO.getTotalFines();  // جمع الغرامات الغير مدفوعة

            // تمرير الغرامات والمجموع إلى صفحة JSP
            request.setAttribute("fines", fines);
            request.setAttribute("totalFines", totalFines+"JO");
            request.getRequestDispatcher("ViewFinesInadmin.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error retrieving fines.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}