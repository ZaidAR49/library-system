package Controller;
import Classes.Book;
import DAO.BookDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class addbookservlet2 extends HttpServlet {
    private BookDAO bookDAO = new BookDAO();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String title = request.getParameter("title");
            String author = request.getParameter("author");
            String genre = request.getParameter("Genre");
            String isbn = request.getParameter("isbn");
          int yearPublished = Integer.parseInt(request.getParameter("yearPublished"));
   
            if (bookDAO.isTitleExists(title)) {
                request.setAttribute("messageAB", "Title already exists. Please enter a different title.");
                request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
                return;
            }
            if (yearPublished < 1300 || yearPublished > 2030) {
                request.setAttribute("messageAB", "Please enter a year between 1300 and 2030.");
                request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
                return;
            }
            Book newBook = new Book();
            newBook.setYearPublished(yearPublished);
            newBook.setTitle(title);
            newBook.setAuthor(author);
            newBook.setGenre(genre);
            newBook.setIsbn(isbn);
        bookDAO.insertBook(newBook);
            request.setAttribute("messageAB", "Book added successfully.");
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            request.setAttribute("messageAB", "An error occurred: " + e.getMessage());
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
        }
    }
}