package Controller;

import Classes.BorrowingTransaction;
import DAO.BorrowingTransactionDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ViweAllBorrowingTransactionServlet", urlPatterns = {"/ViweAllBorrowingTransactionServlet"})
public class ViweAllBorrowingTransactionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        BorrowingTransactionDAO transactionDAO = new BorrowingTransactionDAO();

        try {
            // استرجاع جميع البيانات من قاعدة البيانات
            List<BorrowingTransaction> transactions = transactionDAO.getAllTransactions();

            // تمرير البيانات إلى صفحة JSP
            request.setAttribute("transactions", transactions);
            request.getRequestDispatcher("Viwe-transactionsinadmin.jsp").forward(request, response);

        } catch (Exception e) {
            // تمرير رسالة الخطأ إلى صفحة الخطأ
            request.setAttribute("errorMessage", "Error retrieving transactions: " + e.getMessage());
            request.setAttribute("stackTrace", e); // تمرير كائن الاستثناء بأكمله
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
