package Controller;

import Classes.BorrowingTransaction;
import DAO.BorrowingTransactionDAO;
import DAO.UserDAO;
import Classes.User;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "ViewBooksBorrowedByUserServlet", urlPatterns = {"/ViewBooksBorrowedByUserServlet"})
public class ViewBooksBorrowedByUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username"); // استلام اسم المستخدم من الطلب

        UserDAO userDAO = new UserDAO();
        BorrowingTransactionDAO transactionDAO = new BorrowingTransactionDAO();

        try {
            // البحث عن المستخدم باستخدام اسمه
            User user = userDAO.getUserByUsername(username);

            if (user == null) {
                // إذا لم يكن هناك مستخدم بهذا الاسم
                request.setAttribute("errorMessage", "User not found.");
                request.getRequestDispatcher("error.jsp").forward(request, response);
                return;
            }

            // استرجاع جميع المعاملات (الكتب المستعارة) لهذا المستخدم
            List<BorrowingTransaction> transactions = transactionDAO.getTransactionsByUserId(user.getID());

            if (transactions.isEmpty()) {
                request.setAttribute("messager", "No books borrowed by this user.");
            }

            // تمرير المعاملات إلى صفحة JSP
            request.setAttribute("transactions", transactions);
            request.getRequestDispatcher("Viwe-transactionsinlibrarian.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while retrieving transactions.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}
