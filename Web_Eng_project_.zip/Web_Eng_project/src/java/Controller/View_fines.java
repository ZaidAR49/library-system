/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Classes.Fine;
import Classes.Patron;
import Classes.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ziedr
 */
@WebServlet(name = "View_fines", urlPatterns = {"/View_fines"})
public class View_fines extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.print("GET");

        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
            Statement s = c.createStatement();
            List<Fine> fines = new ArrayList<>();
            User user = (User) request.getSession().getAttribute("user");
           
            //edit fine table to remove transaction // 

            ResultSet rs = s.executeQuery("SELECT * FROM FINES WHERE USER_ID=" + user.getID());
            if (!rs.isBeforeFirst()) {
                // No rows found then
                 request.getRequestDispatcher("No_fines.jsp").forward(request, response);
            }
            while (rs.next()) {
                boolean isPaid = false;
                if (rs.getString("IS_PAID") == "Y") {
                    isPaid = true;
                }

                Fine fine = new Fine(rs.getInt("FINE_ID"), rs.getInt("TRANSACTION_ID"), rs.getInt("USER_ID"), rs.getDouble("FINE_AMOUNT"), isPaid);
                fines.add(fine);
                // to test
               out.print("Fine{fineId=" +fine.getFineID() +
                   ", transactionId=" + fine.getTransactionId() +
                   ", userId=" + fine.getUserId() +
                   ", fineAmount=" + fine.getFineAmount() +
                   ", isPaid=" + fine.isIsPaid() + "}");
            }
            if (null == fines) {
                response.sendRedirect("No_fines.jsp");
            }
            // if fines needed:
            request.getSession().setAttribute("fines", fines);

            request.getRequestDispatcher("vew_fines.jsp").forward(request, response);

        } catch (Exception e) {
            out.print("Somthig went wrong lll---> " + e.getMessage());
        }
    }


}
