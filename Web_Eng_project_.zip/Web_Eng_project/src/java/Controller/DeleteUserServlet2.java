package Controller;

import DAO.UserDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class DeleteUserServlet2 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        try {
            UserDAO userDAO = new UserDAO();
       if (!userDAO.checkUserExists(username)) {
                request.setAttribute("messageDU", "Username does not exist.");
                request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
                return;
            }
            boolean isDeleted = userDAO.deleteUser(username);
            if (isDeleted) {
                request.setAttribute("messageDU", "User deleted successfully.");
            } else {
                request.setAttribute("messageDU", "Failed to delete user.");
            }
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("messageDU", "Error occurred while deleting user.");
            request.getRequestDispatcher("librarian-dashboard.jsp").forward(request, response);
        }
    }
    @Override
    public String getServletInfo() {
        return "Delete User Servlet";
    }}