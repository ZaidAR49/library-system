package Controller;
import Classes.Book;
import DAO.BookDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class ViewBooksServlet extends HttpServlet {
     @Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            BookDAO bookDAO = new BookDAO();
            List<Book> books = bookDAO.getAllBooks();  
            request.setAttribute("booksList", books);
            request.getRequestDispatcher("Viewbook.jsp").forward(request, response);
        } catch (Exception e) {
            request.getRequestDispatcher("error.jsp").forward(request, response);  
        }
    }  
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
