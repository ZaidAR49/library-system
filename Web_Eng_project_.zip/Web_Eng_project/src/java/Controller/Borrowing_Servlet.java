/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Classes.Book;
import Classes.BorrowingTransaction;
import Classes.User;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ziedr
 */
@WebServlet(name = "Borrowing_Servlet", urlPatterns = {"/Borrowing_Servlet"})
public class Borrowing_Servlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Borrowing_Servlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet Borrowing_Servlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        try{
  Class.forName("oracle.jdbc.OracleDriver");
   Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
 Statement s = c.createStatement();
   List<BorrowingTransaction> transactions = new ArrayList<>();
   User user=(User)request.getSession().getAttribute("user");
                ResultSet rs = s.executeQuery("SELECT * FROM BORROWINGTRANSACTION WHERE PATRONID="+user.getID());
                if (!rs.isBeforeFirst()) {
                    // No rows found then
                    out.print("no data found");
                }
                while (rs.next()) {
                    
                    String returnDate; 
                    double fine;
                    if(rs.getString("RETURNDATE")==null){returnDate="Unkown";}
                    else{ returnDate= rs.getString("returnDate");}
                   
                    BorrowingTransaction transaction= new BorrowingTransaction(rs.getInt("transactionID"),rs.getInt("bookID"),rs.getInt("patronID"),rs.getString("borrowDate"),rs.getString("dueDate"),returnDate,rs.getDouble("fineAmount"));
                    
                    out.println("TransactionId: " + transaction.getTransactionID()+
                   ", BookId: " + transaction.getBookID()+
                   ", PatronId: " + transaction.getPatronID()+
                   ", BorrowDate: " + transaction.getBorrowDate() +
                   ", DueDate: " + transaction.getDueDate() +
                   ", ReturnDate: " + transaction.getReturnDate() +
                   ", FineAmount: " + transaction.getFine()+"<hr>");
                    
                  transactions.add(transaction);

                }
                ////////////////////////////////////////////////////
 if(null==transactions){ out.print("message to programer: book is null");}
 ////////////////////////////////////////////////////////
 
                  request.getSession().setAttribute("transactions", transactions);
               
            if("View Borrowing History".equals(request.getParameter("View Borrowing History")))
       request.getRequestDispatcher("View_transactions.jsp").forward(request, response);
else
                  request.getRequestDispatcher("ReturningBook.jsp").forward(request, response);
             

 
 }catch(Exception e){out.print("Somthig went wrong ---> "+e.getMessage());}
        
        
        out.print("all good");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
         response.setContentType("text/html");
        PrintWriter out = response.getWriter();
       try{
           Class.forName("oracle.jdbc.driver.OracleDriver");//load 
     Connection c= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
    Statement s = c.createStatement();
     //////////////////////////// 
     //obj needed
     User user=(User) request.getSession().getAttribute("user");
     
     int bookID= Integer.parseInt(request.getParameter("BbookID"));
     /////
        out.print(user.getID()+"  ,"+bookID+"<hr>");// test
      
       /////////////////////////////////
       Calendar calendar = Calendar.getInstance();
        String borrowDate = calendar.get(Calendar.DAY_OF_MONTH) + " " +(calendar.get(Calendar.MONTH)+1) + " " + calendar.get(Calendar.YEAR);
        // does not mention in the documentation so I will suppose 14 days
        calendar.add(Calendar.DAY_OF_MONTH, 14);
        String dueDate = calendar.get(Calendar.DAY_OF_MONTH) + " " +(calendar.get(Calendar.MONTH)+1) + " " + calendar.get(Calendar.YEAR);                    
         
       PreparedStatement new_Transaction=c.prepareStatement("INSERT INTO BorrowingTransaction (transactionID, bookID, patronID, borrowDate, dueDate) VALUES (IDS.NEXTVAL, ?, ?, ?, ?)" );
      new_Transaction.setInt(1,bookID);
      new_Transaction.setInt(2, user.getID());
        new_Transaction.setString(3, borrowDate);
        new_Transaction.setString(4, dueDate);
       new_Transaction.execute();
       
       
       //////////////////////////////////////
           
        PreparedStatement update_book= c.prepareStatement("UPDATE BOOK SET IS_AVAILABLE = 'N' WHERE ID = " + bookID);
       update_book.execute();
       response.sendRedirect("transaction_successful.html");
       
       out.print("so far so good");
       
       
       
       
       
       }catch(Exception e){
           response.sendRedirect("Error.html");
          // out.print("Somthig went wrong ): thats why -->  "+e.getMessage());
       }
       
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
