/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Classes.BorrowingTransaction;
import Classes.Fine;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transaction;

/**
 *
 * @author ziedr
 */
@WebServlet(name = "ReturnBook", urlPatterns = {"/ReturnBook"})
public class ReturnBook extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ReturnBook</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ReturnBook at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        // out.print("GET IN RETRUNN BOOK");
        // request.getRequestDispatcher("ReturningBook.jsp").forward(request, response);
//       BorrowingTransaction return_transaction=(BorrowingTransaction)request.getSession().getAttribute("return_transaction");
//       out.print(return_transaction.getTransactionID());

        String x = request.getParameter("transactionID");
        int Return_trans = 0;
        try {
            Return_trans = Integer.parseInt(x);

            Class.forName("oracle.jdbc.OracleDriver");
            Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
            Statement s = c.createStatement();
///////////////////////////////////////////////////////////////////////////////////////////////////////////
            Calendar calendar = Calendar.getInstance();
            String returnDate = calendar.get(Calendar.DAY_OF_MONTH) + " " + (calendar.get(Calendar.MONTH) + 1) + " " + calendar.get(Calendar.YEAR);;
            PreparedStatement update_trans1 = c.prepareStatement("UPDATE BORROWINGTRANSACTION SET returndate ='" + returnDate + "' WHERE transactionID = " + Return_trans);
             update_trans1.execute();
         
            ResultSet rs = s.executeQuery("SELECT * FROM BORROWINGTRANSACTION WHERE transactionID =" + Return_trans);
            if (!rs.isBeforeFirst()) {
                // No rows found then
                out.print("no data found");
            }
            while (rs.next()) {

                BorrowingTransaction transaction = new BorrowingTransaction(rs.getInt("transactionID"), rs.getInt("bookID"), rs.getInt("patronID"), rs.getString("borrowDate"), rs.getString("dueDate"), returnDate, rs.getDouble("fineAmount"));
transaction.fineamount();
// set book available 
    PreparedStatement update_book = c.prepareStatement("UPDATE book SET is_available ='Y' WHERE ID = " + transaction.getBookID());
update_book.execute();
if(transaction.getFine()>0)
{
PreparedStatement update_trans2 = c.prepareStatement("UPDATE BORROWINGTRANSACTION SET fineAmount ='" + transaction.getFine()+ "' WHERE transactionID = " + Return_trans);
update_trans2.execute();
//////////////////////////////INSERT NEW FINE
String N="N";
//PreparedStatement new_Fine=c.prepareStatement("INSERT INTO Fines (Fine_ID,transactionID,USER_ID, fine_amount, ISPaid) VALUES (IDS.NEXTVAL, ?, ?, ?, ?)" );
//      new_Fine.setInt(1,transaction.getTransactionID());
//      new_Fine.setInt(2, transaction.getPatronID());
//        new_Fine.setDouble(3, transaction.getFine());
//        new_Fine.setString(4, N);
//       new_Fine.execute();
}
// Test
//out.println("TransactionId: " + transaction.getTransactionID()
//                        + ", BookId: " + transaction.getBookID()
//                        + ", PatronId: " + transaction.getPatronID()
//                        + ", BorrowDate: " + transaction.getBorrowDate()
//                        + ", DueDate: " + transaction.getDueDate()
//                        + ", ReturnDate: " + transaction.getReturnDate()
//                        + ", FineAmount: " + transaction.getFine() + "<hr>");
request.setAttribute("fine", transaction.getFine());
           request.getRequestDispatcher("BookReturned.jsp").forward(request, response);
            }

        } catch (Exception e) {
           // response.sendRedirect("Error.html");
            out.print("Error-->" + e.getMessage());
        }

        // out.print("this -->" + Return_trans);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
