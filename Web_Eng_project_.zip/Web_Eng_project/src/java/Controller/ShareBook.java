/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Classes.SharingBook;
import Classes.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ziedr
 */
@WebServlet(name = "ShareBook", urlPatterns = {"/ShareBook"})
public class ShareBook extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            User user = (User) request.getSession().getAttribute("user");
            Class.forName("oracle.jdbc.driver.OracleDriver");//load 
            Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
            Statement s = c.createStatement();
            ////////////////////////////////////////////////////
            List<SharingBook> books = new ArrayList<>();

            ResultSet rs = s.executeQuery("SELECT * FROM SHAREDBOOK WHERE RECEIVER_ID=" + user.getID());
            while (rs.next()) {

                SharingBook book = new SharingBook(rs.getInt("ID"), rs.getInt("BOOK_ID"), rs.getInt("RECEIVER_ID"), rs.getInt("SENDER_ID"));
                books.add(book);
                
                //test
                //out.print("bookid:"+book.getBookId()+"  id: " + book.getId() +"sender"+ book.getSenderId()+"  reciver "+book.getReceiverId());
            }
            request.getSession().setAttribute("sharedBooks", books);
            request.getRequestDispatcher("SharedBooks.jsp").forward(request, response);
        } catch (Exception e) {
            out.print("Oops--> " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            int bookID = Integer.parseInt(request.getParameter("bookID"));
            int otherID = Integer.parseInt(request.getParameter("sharedUser"));
            User user = (User) request.getSession().getAttribute("user");

            ////////////////////////////////////////////////////////////////
            Class.forName("oracle.jdbc.driver.OracleDriver");//load 
            Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
            Statement s = c.createStatement();
            //////////////////////////////////////////////
            PreparedStatement new_comment = c.prepareStatement("INSERT INTO sharedBook  (ID, book_ID, receiver_ID, sender_ID) VALUES (IDS.NEXTVAL, ?, ?, ?)");
            new_comment.setInt(1, bookID);
            new_comment.setInt(2, otherID);
            new_comment.setInt(3, user.getID());

            new_comment.execute();

            request.getRequestDispatcher("Search_Book_Result.jsp").forward(request, response);
        } catch (Exception e) {
            out.print("Oops--> " + e.getMessage());
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
