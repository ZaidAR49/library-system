package Controller;

import Classes.Book;
import DAO.BookDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "FilterBookServlet3", urlPatterns = {"/FilterBookServlet3"})
public class FilterBookServlet3 extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // استلام الحالة من النموذج
        String availability = request.getParameter("availability"); // "available" أو "not_available"
        
        try {
            BookDAO bookDAO = new BookDAO();
            boolean isAvailable = "available".equals(availability); // إذا كانت القيمة "available" تعني المتاحة
            List<Book> filteredBooks = bookDAO.getBooksByAvailability(isAvailable);

            // إرسال قائمة الكتب إلى صفحة JSP
            request.setAttribute("booksList", filteredBooks);
            request.setAttribute("selectedAvailability", availability); // حفظ الخيار المحدد
            request.getRequestDispatcher("Viewbook3.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "An error occurred while filtering books.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Servlet for filtering books by availability.";
    }
}