/*package Controller;

import Classes.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
public class LoginServlet extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       try {
            User user = null;
            
            Class.forName("oracle.jdbc.OracleDriver");
            Connection c= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Abd2002*");
            
            String username = request.getParameter("username");
            String password = request.getParameter("password");
           
            String checkUserQuery = "SELECT * FROM LUSER WHERE USERNAME = ?";
            PreparedStatement psUser = c.prepareStatement(checkUserQuery);
            psUser.setString(1, username);
            ResultSet rsUser = psUser.executeQuery();
             if (!rsUser.next()) {
       
        response.sendRedirect("index.html?messageLG=Username is incorrect");
    } else {
      
        String checkPasswordQuery = "SELECT * FROM LUSER WHERE USERNAME = ? AND PASSWORD = ?";
        PreparedStatement psPassword = c.prepareStatement(checkPasswordQuery);
        psPassword.setString(1, username);
        psPassword.setString(2, password);
        ResultSet rsPassword = psPassword.executeQuery();
             if (!rsPassword.next()) {
          
            response.sendRedirect("index.html?messageLG=Password is incorrect");
             }else{
                 HttpSession session = request.getSession(true);
                session.setAttribute("welcome", username);
                 String role = rsPassword.getString("ROLE");
                switch (role) {
                    case "Administrator":
                        response.sendRedirect("admin-dashboard.jsp");
                        break;
                    case "Librarian":
                        response.sendRedirect("librarian-dashboard.jsp");
                        break;
                    case "Patron":
                        response.sendRedirect("patron-dashboard.jsp");
                        break;
                }
            } }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }}}*/
package Controller;

import Classes.User;
import DAO.UserDAO;

import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve username and password from the request
            String username = request.getParameter("username");
            String password = request.getParameter("password");

            // Get user from DAO
            UserDAO userDAO = new UserDAO();
            User user = userDAO.getUserByUsername(username);

            if (user == null) {
                // User not found
                response.sendRedirect("index.html?messageLG=Username is incorrect");
            } else if (!user.getPassword().equals(password)) {
                // Incorrect password
                response.sendRedirect("index.html?messageLG=Password is incorrect");
            } else {
                // Login successful
                HttpSession session = request.getSession(true);
                session.setAttribute("welcome", username);

                // Redirect based on role
                switch (user.getRole()) {
                    case "Administrator":
                        response.sendRedirect("admin-dashboard.jsp");
                        break;
                    case "Librarian":
                        response.sendRedirect("librarian-dashboard.jsp");
                        break;
                    case "Patron":
                        request.getSession().setAttribute("user", user);
                        response.sendRedirect("patron-dashboard.jsp");
                        break;
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.sendRedirect("index.html?messageLG=An error occurred during login");
        } catch (Exception ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}