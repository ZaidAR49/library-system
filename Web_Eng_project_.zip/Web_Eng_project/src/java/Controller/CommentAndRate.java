/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Classes.Fine;
import Classes.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ziedr
 */
@WebServlet(name = "CommentAndRate", urlPatterns = {"/CommentAndRate"})
public class CommentAndRate extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
         response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.print("Right bath");
        
       
        
        try{
            String comment=request.getParameter("userComment");
            if(comment==null){out.print("inter comment");}
            else{
            int bookID=Integer.parseInt(request.getParameter("bookID"));
            User user=(User)request.getSession().getAttribute("user");
            ////////////////////////////////////////////////////////////////
             Class.forName("oracle.jdbc.driver.OracleDriver");//load 
     Connection c= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
    Statement s = c.createStatement();
            //////////////////////////////////////////////////////////////////
           
            
             PreparedStatement new_comment=c.prepareStatement("INSERT INTO Comments (comment_ID, book_ID, Patron_ID, bcomment) VALUES (IDS.NEXTVAL, ?, ?, ?)" );
      new_comment.setInt(1,bookID);
      new_comment.setInt(2, user.getID());
        new_comment.setString(3, comment);
        
       new_comment.execute();
            
               request.getRequestDispatcher("Search_Book_Result.jsp").forward(request, response);
            }
            }catch(Exception e){
                out.print(e.getMessage());
            }
            /////////////////////////////////////////////////////////////
                
       
            try{
            int rate= Integer.parseInt(request.getParameter("rating"));
            if(rate==0){out.print("inter comment");}
            else{
            int bookID=Integer.parseInt(request.getParameter("bookID"));
            User user=(User)request.getSession().getAttribute("user");
            ////////////////////////////////////////////////////////////////
             Class.forName("oracle.jdbc.driver.OracleDriver");//load 
     Connection c= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","1234");
    Statement s = c.createStatement();
            //////////////////////////////////////////////////////////////////
           
            
             PreparedStatement new_rate=c.prepareStatement("INSERT INTO RATINGS (RATING_ID, BOOK_ID, Patron_ID, RATING) VALUES (IDS.NEXTVAL, ?, ?, ?)" );
      new_rate.setInt(1,bookID);
      new_rate.setInt(2, user.getID());
        new_rate.setInt(3, rate);
        
       new_rate.execute();
               request.getRequestDispatcher("Search_Book_Result.jsp").forward(request, response);
        
            }
            }catch(Exception e){
                out.print(e.getMessage());
            }
        }
    /////////////////////////////////////////////////////////////////////////////////////////////
        @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                response.setContentType("text/html");
                 PrintWriter out = response.getWriter();
       // out.print("Right Bath");
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
            Statement s = c.createStatement();
            List<String> Comments = new ArrayList<>();
            List<Integer> Rates= new ArrayList<>();
             int bookID=Integer.parseInt(request.getParameter("bookID"));
           //out.print(bookID);
            //edit fine table to remove transaction // 

            ResultSet rs1 = s.executeQuery("SELECT BCOMMENT FROM COMMENTS WHERE BOOK_ID="+ bookID);
           
          
            while (rs1.next()) {
               
             String com=rs1.getString("BCOMMENT");
Comments.add(com);
               
                // to test
               out.print(com+"<br>"); 
                  
            }
           //////////////////////////////////////////////////////////////////
           
         ResultSet rs2 = s.executeQuery("SELECT RATING FROM RATINGS WHERE BOOK_ID=" + bookID);
 
            while (rs2.next()) {
               
             int rate =rs2.getInt("RATING");
Rates.add(rate);
               
                // to test
               out.print(rate+"<br>"); 
                  
            }
            request.setAttribute("comments", Comments);
            request.setAttribute("rates", Rates);
           request.getRequestDispatcher("view_commentsAndRartes.jsp").forward(request, response);

        } catch (Exception e) {
            out.print("Somthig went wrong lll---> " + e.getMessage());
        }
    } 

}
