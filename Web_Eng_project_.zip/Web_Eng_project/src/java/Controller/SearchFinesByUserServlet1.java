package Controller;

import DAO.FineDAO;
import DAO.UserDAO;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SearchFinesByUserServlet1", urlPatterns = {"/SearchFinesByUserServlet1"})
public class SearchFinesByUserServlet1 extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userName = request.getParameter("userName"); // اسم المستخدم من النموذج
        FineDAO fineDAO = new FineDAO();
        UserDAO userDAO = new UserDAO();

        try {
            // الحصول على معرف المستخدم بناءً على الاسم
            int userId = userDAO.getUserIdByName(userName);
            
            if (userId == -1) { // إذا لم يتم العثور على المستخدم
                request.setAttribute("messagef", "Not found user");
                request.getRequestDispatcher("ViewFinesInadmin.jsp").forward(request, response);
                return;
            }

            // حساب مجموع الغرامات غير المدفوعة
            double totalFines = fineDAO.getUnpaidFinesByUserId(userId);

            if (totalFines > 0) {
                request.setAttribute("messagef", "Total unpaid fines: " + totalFines+"JO");
            } else {
                request.setAttribute("messagef", "There are no unpaid fines for this user.");
            }

            request.getRequestDispatcher("ViewFinesInadmin.jsp").forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while searching for fines.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}