package Controller;

import Classes.Book;
import DAO.BookDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "FilterBookServlet2", urlPatterns = {"/FilterBookServlet2"})
public class FilterBookServlet2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            BookDAO bookDAO = new BookDAO();
            List<Book> books;
      String genre = request.getParameter("genre");
                books = bookDAO.getBooksByGenre(genre); 
            request.setAttribute("booksList", books);

            request.getRequestDispatcher("Viewbook2.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
           
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
    @Override
    public String getServletInfo() {
        return "Servlet to filter books by genre.";
    }
}