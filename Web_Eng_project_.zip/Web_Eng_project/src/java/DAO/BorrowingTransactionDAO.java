package DAO;

import Classes.BorrowingTransaction;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BorrowingTransactionDAO {
   

   private Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.OracleDriver");
        return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
    }

    public List<BorrowingTransaction> getAllTransactions() throws Exception {
        List<BorrowingTransaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM BorrowingTransaction ";

        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
//CREATE TABLE BorrowingTransaction (transactionID NUMBER PRIMARY KEY, bookID NUMBER NOT NULL, patronID NUMBER NOT NULL,
//borrowDate VARCHAR2(20) NOT NULL, dueDate  VARCHAR2(20)NOT NULL, returnDate VARCHAR2(20), fineAmount NUMBER DEFAULT 0, FOREIGN KEY (bookID) 
//REFERENCES book(ID),FOREIGN KEY (patronID) REFERENCES LUSER(id))")
            while (rs.next()) {
                BorrowingTransaction transaction = new BorrowingTransaction();
                transaction.setTransactionID(rs.getInt("transactionID"));
                transaction.setBookID(rs.getInt("bookID"));
                transaction.setPatronID(rs.getInt("patronID"));
                transaction.setBorrowDate(rs.getString("borrowDate"));
                transaction.setDueDate(rs.getString("dueDate"));
                transaction.setReturnDate(rs.getString("returnDate"));
                transaction.setFine(rs.getDouble("fineAmount"));

                transactions.add(transaction);
            }
        }

        return transactions;
    }
    public List<BorrowingTransaction> getTransactionsByUserId(int userId) throws Exception {
        List<BorrowingTransaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM BorrowingTransaction WHERE patronID = ?";

        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, userId); // تمرير الـ patronID كـ parameter

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    BorrowingTransaction transaction = new BorrowingTransaction();
                    transaction.setTransactionID(rs.getInt("transactionID"));
                    transaction.setBookID(rs.getInt("bookID"));
                    transaction.setPatronID(rs.getInt("patronID"));
                    transaction.setBorrowDate(rs.getString("borrowDate"));
                    transaction.setDueDate(rs.getString("dueDate"));
                    transaction.setReturnDate(rs.getString("returnDate"));
                    transaction.setFine(rs.getDouble("fineAmount"));

                    transactions.add(transaction);
                }
            }
        }

        return transactions;
    }
}