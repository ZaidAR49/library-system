package DAO;
import Classes.Fine;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class FineDAO {
    
  private Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.OracleDriver");
        return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
    }
    public List<Fine> getAllFines() throws SQLException, ClassNotFoundException {
        List<Fine> fines = new ArrayList<>();
        String query = "SELECT * FROM FINES";
        //CREATE TABLE FINES (FINE_ID NUMBER, TRANSACTION_ID NUMBER NOT NULL, USER_ID NUMBER NOT NULL, FINE_AMOUNT NUMBER NOT NULL,
        //IS_PAID CHAR(1) DEFAULT 'N' CHECK (IS_PAID IN ('Y', 'N')), PRIMARY KEY (FINE_ID),
        //FOREIGN KEY (TRANSACTION_ID) REFERENCES BorrowingTransaction(transactionID),
        //FOREIGN KEY (USER_ID) REFERENCES LUSER(ID))");
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                Fine fine = new Fine();
                fine.setFineID(rs.getInt("FINE_ID"));
                fine.setTransactionId(rs.getInt("TRANSACTION_ID"));
                fine.setUserId(rs.getInt("USER_ID"));
                fine.setFineAmount(rs.getDouble("FINE_AMOUNT"));
                fine.setIsPaid("Y".equals(rs.getString("IS_PAID")));
                fines.add(fine);
            }
        }
        return fines;
    } 
    public double getTotalFines() throws SQLException, ClassNotFoundException {
        double totalFines = 0;
        String query = "SELECT SUM(FINE_AMOUNT) FROM FINES WHERE IS_PAID = 'N'";
        
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            
            if (rs.next()) {
                totalFines = rs.getDouble(1);
            }
        }
        return totalFines;
    }
    public List<Fine> getFinesByUserName(String userName) throws SQLException, ClassNotFoundException {
    List<Fine> fines = new ArrayList<>();
    String query = "SELECT f.* FROM FINES f "
                 + "JOIN LUSER l ON f.USER_ID = l.ID "
                 + "WHERE l.USERNAME = ?";

    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, userName);
        
        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Fine fine = new Fine();
                fine.setFineID(rs.getInt("FINE_ID"));
                fine.setTransactionId(rs.getInt("TRANSACTION_ID"));
                fine.setUserId(rs.getInt("USER_ID"));
                fine.setFineAmount(rs.getDouble("FINE_AMOUNT"));
                fine.setIsPaid(rs.getBoolean("IS_PAID"));
                
                fines.add(fine);
            }
        }
    }
    return fines;
}
   public double getUnpaidFinesByUserId(int userId) throws SQLException, ClassNotFoundException {
    double totalFines = 0;
    String query = "SELECT SUM(FINE_AMOUNT) FROM FINES WHERE USER_ID = ? AND IS_PAID = 'N'";

    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setInt(1, userId);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                totalFines = rs.getDouble(1);
            }
        }
    }
    return totalFines;
}
}
