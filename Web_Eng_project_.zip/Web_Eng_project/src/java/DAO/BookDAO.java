/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author User
 */
import Classes.Book;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class BookDAO {
    private Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.OracleDriver");
        return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
    }

    public boolean isTitleExists(String title) throws SQLException, ClassNotFoundException {
        String query = "SELECT COUNT(*) FROM BOOK WHERE TITLE = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, title);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0; // إذا كان العنوان موجودًا بالفعل
            }
        }
        return false;
    }

    public void insertBook(Book book) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO BOOK(ID, YEAR_PUBLISHED, TITLE, AUTHOR, GENRE, ISBN) VALUES (ids.NEXTVAL, ?, ?, ?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, book.getYearPublished());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthor());
            ps.setString(4, book.getGenre());
            ps.setString(5, book.getIsbn());
            ps.executeUpdate();
        }
    }
     public boolean deleteBook(String title) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM BOOK WHERE TITLE = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, title);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0; // Return true if book was deleted
        }
    }
     public List<Book> getAllBooks() throws SQLException, ClassNotFoundException {
        List<Book> books = new ArrayList<>();
        String query = "SELECT * FROM BOOK";
        
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("ID"));
                book.setTitle(rs.getString("TITLE"));
                book.setAuthor(rs.getString("AUTHOR"));
                book.setGenre(rs.getString("GENRE"));
                book.setIsbn(rs.getString("ISBN"));
                book.setYearPublished(rs.getInt("YEAR_PUBLISHED"));
                if(rs.getString("IS_AVAILABLE").equals("Y"))
                book.setIsAvailable(true);
                else 
                book.setIsAvailable(false);
                if(rs.getString("IS_RESERVED").equals("Y"))
                book.setIsReserved(true);
                else 
                book.setIsReserved(false);
                books.add(book);
            }
        }
        return books;
    }
    public List<Book> getBooksByGenre(String genre) throws Exception {
    List<Book> books = new ArrayList<>();
    String fil = "SELECT * FROM BOOK WHERE genre = ?";

    try (Connection connection = getConnection(); // افترض وجود DatabaseConnection
         PreparedStatement stmt = connection.prepareStatement(fil)) {
        stmt.setString(1, genre);
        ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setGenre(rs.getString("genre"));
                book.setIsbn(rs.getString("isbn"));
                book.setYearPublished(rs.getInt("year_published"));
                if(rs.getString("IS_AVAILABLE").equals("Y"))
                book.setIsAvailable(true);
                else 
                book.setIsAvailable(false);
                if(rs.getString("IS_RESERVED").equals("Y"))
                book.setIsReserved(true);
                else 
                book.setIsReserved(false);
                books.add(book);
            }
        }
    
    return books;
}
 public boolean updateBook(String oldTitle, String newTitle, String newAuthor, String newGenre) throws Exception {
        String query = "UPDATE BOOK SET TITLE = ?, AUTHOR = ?, GENRE = ? WHERE TITLE = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, newTitle);
            ps.setString(2, newAuthor);
            ps.setString(3, newGenre);
            ps.setString(4, oldTitle);
            return ps.executeUpdate() > 0;
        }
    }
   public List<Book> getBooksByAvailability(boolean isAvailable) throws Exception {
    List<Book> books = new ArrayList<>();
    String query = "SELECT * FROM BOOK WHERE IS_AVAILABLE = ?";

    try (Connection connection = getConnection(); 
         PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, isAvailable ? "Y" : "N"); // "Y" إذا كان متاحًا، "N" إذا لم يكن متاحًا
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setGenre(rs.getString("genre"));
            book.setIsbn(rs.getString("isbn"));
            book.setYearPublished(rs.getInt("year_published"));
            book.setIsAvailable("Y".equals(rs.getString("IS_AVAILABLE")));
            book.setIsReserved("Y".equals(rs.getString("IS_RESERVED")));
            books.add(book);
        }
    }
    return books;
} 
}

