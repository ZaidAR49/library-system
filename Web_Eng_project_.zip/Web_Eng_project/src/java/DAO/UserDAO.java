package DAO;
import Classes.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class UserDAO {
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            return DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "1234");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Database connection failed", e);
        }
    }
    public boolean checkUserExists(String username) throws SQLException {
        String query = "SELECT COUNT(*) FROM LUSER WHERE USERNAME = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            rs.next();
            return rs.getInt(1) > 0;
        }
    }
    public void addUser(User user) throws SQLException {
        String query = "INSERT INTO LUSER (USERNAME, PASSWORD, ROLE, ID) VALUES (?, ?, ?, IDS.NEXTVAL)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getRole());
            ps.executeUpdate();
        }
    }
     public boolean deleteUser(String username) throws Exception {
        String query = "DELETE FROM LUSER WHERE USERNAME = ?";
        try (Connection connection = getConnection();
             PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, username);
            return ps.executeUpdate() > 0;
        }
    }
     public int getUserIdByName(String userName) throws SQLException, ClassNotFoundException {
    int userId = -1; 
    String query = "SELECT ID FROM LUSER WHERE USERNAME = ?";

    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(query)) {
        stmt.setString(1, userName);
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                userId = rs.getInt("ID");
            }
        }
    }

    return userId;
}
public List<User> getAllUsers() throws SQLException, ClassNotFoundException {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM LUSER"; // افترض أن جدول المستخدمين هو "LUSER"

        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                User user = new User();
                user.setID(rs.getInt("ID"));
                user.setUsername(rs.getString("USERNAME"));
                user.setPassword(rs.getString("PASSWORD"));
                user.setRole(rs.getString("ROLE"));
                users.add(user);
            }
        }

        return users;
    }
public User getUserByUsername(String username) throws Exception {
        User user = null;
        String query = "SELECT * FROM LUSER WHERE username = ?";

        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            
            stmt.setString(1, username);  // تعيين اسم المستخدم كـ parameter

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    user = new User();
                    user.setID(rs.getInt("ID"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setRole(rs.getString("role"));
                }
            }
        }

        return user;
    }
 
}

