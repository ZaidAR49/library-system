/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author ziedr
 */
public class Fine {
  private  int fineID;
private int transactionId;
private int userId;
private double fineAmount;
private boolean isPaid; 
   
public Fine(){}

    public Fine(int fineID,int transactionId,int userId, double fineAmount, boolean isPaid) {
       this.fineID= fineID;
        this.transactionId = transactionId;
        this.userId=userId;
        this.fineAmount = fineAmount;
        this.isPaid = isPaid;
    }

    public int getFineID() {
        return fineID;
    }

    public void setFineID(int fineID) {
        this.fineID = fineID;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }


    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public boolean isIsPaid() {
        return isPaid;
    }

    public void setIsPaid(boolean isPaid) {
        this.isPaid = isPaid;
    }
    public static long dateDifference(String date1, String date2) {
        // تقسيم النصوص إلى أجزاء وتحويلها إلى أرقام
        String[] parts1 = date1.split("-");
        String[] parts2 = date2.split("-");
        
        int year1 = Integer.parseInt(parts1[0]);
        int month1 = Integer.parseInt(parts1[1]);
        int day1 = Integer.parseInt(parts1[2]);
        
        int year2 = Integer.parseInt(parts2[0]);
        int month2 = Integer.parseInt(parts2[1]);
        int day2 = Integer.parseInt(parts2[2]);
        
        // إنشاء كائنات LocalDate
        LocalDate d1 = LocalDate.of(year1, month1, day1);
        LocalDate d2 = LocalDate.of(year2, month2, day2);
        
        // حساب الفرق بالأيام
        return Math.abs(ChronoUnit.DAYS.between(d1, d2));
    }
}
