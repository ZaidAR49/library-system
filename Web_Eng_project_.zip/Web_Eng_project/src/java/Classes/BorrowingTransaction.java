/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author ziedr
 */
public class BorrowingTransaction {

    private int transactionID;
    private int bookID;
    private int patronID;
    private String borrowDate;
    private String dueDate;
    private String returnDate;
    private double fine; 
public BorrowingTransaction(){}
    public BorrowingTransaction(int transactionID, int bookID, int patronID, String borrowDate, String dueDate,String returnDate,double fine) {
        this.transactionID = transactionID;
        this.bookID = bookID;
        this.patronID = patronID;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = returnDate;
        this.fine=fine;
        
    }

    public void setTransactionID(int transactionID) {
        this.transactionID = transactionID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public void setPatronID(int patronID) {
        this.patronID = patronID;
    }

    public void setBorrowDate(String borrowDate) {
        this.borrowDate = borrowDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public boolean isOverdue() {
       return false;
    }

    public int getTransactionID() {
        return transactionID;
    }

    public int getBookID() {
        return bookID;
    }

    public int getPatronID() {
        return patronID;
    }

    public String getBorrowDate() {
        return borrowDate;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public double getFine() {
        return fine;
    }

    public void setFine(double fine) {
        this.fine = fine;
    }

   public void fineamount(){


        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MM yyyy");

        try {
            Date dueDate_d = dateFormat.parse(dueDate);
            Date returnDate_d= dateFormat.parse(returnDate); 
            
            if(!returnDate_d.after(dueDate_d)){fine=0;}
            else{
                
             ///////////////////////////////////////////////////////////////////////////
            long differenceInMillis = returnDate_d.getTime() - dueDate_d.getTime();
            // Convert milliseconds to days
           double differenceInDays = (double) differenceInMillis / (1000 * 60 * 60 * 24);
fine = differenceInDays;
            }
        } catch (Exception e) {
            System.out.println("Error-->" + e.getMessage());
        }

   
}

}
