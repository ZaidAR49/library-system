/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ziedr
 */
public class Patron extends User{
    private String patrontype;
     private List<BorrowingTransaction> borrowingHistory;
  private double fineAmount=0;

    public Patron(int id, String username, String password, String role,String patrontype) {
        super(id, username, password, role);
        this.patrontype = patrontype;
        this.borrowingHistory = new ArrayList<>();
        this.fineAmount = 0.0;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public String getPatrontype() {
        return patrontype;
    }

    public List<BorrowingTransaction> getBorrowingHistory() {
        return borrowingHistory;
    }
public void addTransaction(BorrowingTransaction transaction) {
        borrowingHistory.add(transaction);
        System.out.println("Transaction added for book ID: " + transaction.getBookID());
    }
}
