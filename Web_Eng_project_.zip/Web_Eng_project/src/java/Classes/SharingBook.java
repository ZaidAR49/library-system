/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author ziedr
 */
public class SharingBook {
      private int id;             // Primary Key
    private int bookId;         // Book ID
    private int receiverId;     // Receiver's User ID (Foreign Key)
    private int senderId;     

    public SharingBook(int id, int bookId, int receiverId, int senderId) {
        this.id = id;
        this.bookId = bookId;
        this.receiverId = receiverId;
        this.senderId = senderId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getReceiverId() {
        return receiverId;
    }

    public void setReceiverId(int receiverId) {
        this.receiverId = receiverId;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }
    
}
