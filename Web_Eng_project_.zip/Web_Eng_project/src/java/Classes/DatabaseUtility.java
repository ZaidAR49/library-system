/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author User
 */
public class DatabaseUtility {

    private static final String URL = "jdbc:mysql://localhost:3306/librarydb"; // عنوان قاعدة البيانات
    private static final String USER = "system"; // اسم المستخدم
    private static final String PASSWORD = "Abd2002*"; // كلمة المرور

    // للحصول على الاتصال بقاعدة البيانات
    public static Connection getConnection() {
        try {
            // تحميل الدرايفر الخاص بقاعدة البيانات (إذا لزم الأمر، يمكن تحميله بشكل تلقائي)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // إنشاء الاتصال باستخدام بيانات الاتصال
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // دالة لإغلاق الاتصال (يمكن استخدامها في حال كان الاتصال لا يزال مفتوحاً)
    public static void closeConnection(Connection connection) {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}